#! /bin/bash
given_number=$1
if  [[ ${given_number} -gt 1000 ]]
then echo "condition is true"
else
echo "show me false condition"
fi

