#! /bin/bash
num_of_args=$#
first_arg=$1
second_arg=$2
third_arg=$3
echo "first_name refers to $1"
echo "second_name refers to $2"
echo "address refers to $3"
 


