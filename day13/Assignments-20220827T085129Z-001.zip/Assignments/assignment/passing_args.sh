#! /bin/bash
number_of_args=$#
first_arg=$1
second_arg=$2
A="$(( $1*$2 ))"
echo "product  of $1*$2 is $A"



