#! /bin/bash
sample_num=$1
if [[ ${sample_num} -ge 1200 ]]
then
echo "it is true"
else
echo "it is false"
fi

