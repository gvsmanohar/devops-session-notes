#! /bin/bash
choosen_num=$1

if [[ ${choosen_num} -lt 300 && ${choosen_num} -ge 200  ]]
then
echo "it is right"
else
echo "show me valid"
fi





