#! /bin/bash
given_number=$1
if [[ ${given_number} -ne 50 ]] 
then
echo "condition is right"
else
echo "condition is wrong"
fi
