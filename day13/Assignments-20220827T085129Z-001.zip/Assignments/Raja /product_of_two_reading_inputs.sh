#!/bin/bash/

echo "please enter first number"
read number1
echo "please enter second numner"
read number2
product=$((number1*number2))
echo "product of $number1 and $number2 is" $product



