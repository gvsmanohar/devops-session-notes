

#!/bin/bash

args_count=$#
args_list=$@
echo "number of args: ${args_count}"
echo "list of args: ${args_list}"



