#!/bin/bash
#multiply two numbers
echo "enter A value : "
read A
echo "enter B value : "
read B
echo "c=$(($A*$B))"
echo $c

