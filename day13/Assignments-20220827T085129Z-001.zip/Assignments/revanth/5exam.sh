#!/bin/bash
number_of_list=$@
number_of_args=$#
echo "$number_of_list"
echo "$number_of_args"
