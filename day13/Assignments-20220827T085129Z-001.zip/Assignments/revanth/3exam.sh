#!/bin/bash
number_of_arguments=$#
frist_argument=$1
echo "first name is $1"
second_argument=$2
echo " last name is $2"
third_argument=$3
echo "address is $3"


