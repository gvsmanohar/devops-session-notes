#!/bin/bash
#multiplication of two numbers using two arguments
number_of_arguments=$#
frist_argument=$1
second_argument=$2
M=$(($1*$2))
echo "product of $1* $2 is $M"







