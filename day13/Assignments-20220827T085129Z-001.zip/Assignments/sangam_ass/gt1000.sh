
#!/bin/bash


var1=$1
var2=1000




if [[ $var1 -gt $var2 ]]
then
echo "$var1 is greater than $var2"
else
echo "the number is not greater than 1000"
fi
