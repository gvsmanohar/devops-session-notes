#!/bin/bash
list=$@

number=$#
echo "$list"
echo "$number"
