#!/bin/bash

var1=$1





if [[ $var1 -ge 1200 ]]


then

echo "the give number is greater than or equal to"

else

echo "the given number is less than"

fi
