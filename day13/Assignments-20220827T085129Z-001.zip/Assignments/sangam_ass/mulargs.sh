#!/bin/bash


arg1=$1


arg2=$2

multiplication=$(($1*$2))


echo "$multiplication" 
