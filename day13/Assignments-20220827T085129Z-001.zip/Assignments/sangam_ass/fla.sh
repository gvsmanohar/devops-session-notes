#!/bin/bash



firstname=$1 


lastname=$2 

address=$3 





echo "$firstname"

echo "$lastname"

echo "$address"


