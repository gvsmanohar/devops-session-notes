#!/bin/bash


number1=$1

if [[ $number -lt 300 ]]

then




echo "the given number is less than 300" 


elif [[ $number -ge 200 ]]
then


echo "the given number is greater tha equal to 200" 
else

echo "entered number is neither nor"
fi
     
