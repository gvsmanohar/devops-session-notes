#!/bin/bash

number=$1

if [[ $number -ne 50 ]]

then

echo "the given number is not equal to"

else

echo "the given number is equal to"

fi
     
